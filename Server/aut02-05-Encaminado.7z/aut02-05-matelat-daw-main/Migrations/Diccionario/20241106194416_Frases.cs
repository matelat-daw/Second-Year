﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace AUT02_05.Migrations.Diccionario
{
    /// <inheritdoc />
    public partial class Frases : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Frases",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SpanishFrase = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    EnglishFrase = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    TermId = table.Column<int>(type: "int", nullable: false),
                    Termsid = table.Column<int>(type: "int", nullable: true),
                    UserId = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Frases", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Frases_Espeng_Termsid",
                        column: x => x.Termsid,
                        principalTable: "Espeng",
                        principalColumn: "id");
                });

            migrationBuilder.InsertData(
                table: "Frases",
                columns: new[] { "Id", "EnglishFrase", "SpanishFrase", "TermId", "Termsid", "UserId" },
                values: new object[,]
                {
                    { 1, "\"They zoomed in on the image to see more details.\"", "\"Hicieron un zoom sobre la imagen para ver más detalles.\"", 19489, null, null },
                    { 2, "\"The zoologist was observing the behavior of the elephants.\"", "\"El zoólogo estaba observando el comportamiento de los elefantes.\"", 19488, null, null },
                    { 3, "\"We went to the zoo to see the lions and tigers.\"", "\"Fuimos al zoo a ver a los leones y tigres.\"", 19485, null, null },
                    { 4, "\"The zonal area has direct access to the highway.\"", "\"El área zonal tiene acceso directo a la autopista.\"", 19484, null, null },
                    { 5, "\"The zipper on my jacket is broken.\"", "\"La cremallera de mi chaqueta está rota.\"", 5344, null, null },
                    { 6, "\"Zion is a city mentioned in many biblical texts.\"", "\"Sión es una ciudad mencionada en muchos textos bíblicos.\"", 17156, null, null },
                    { 7, "\"The number zero is fundamental in mathematics.\"", "\"El número cero es fundamental en matemáticas.\"", 3743, null, null },
                    { 8, "\"The zebra has black and white stripes.\"", "\"La cebra tiene rayas blancas y negras.\"", 3626, null, null },
                    { 9, "\"She is a zealous person who always supports new projects.\"", "\"Ella es una persona entusiasta que siempre apoya nuevos proyectos.\"", 7557, null, null },
                    { 10, "\"The zealot defended his belief with great fervor.\"", "\"El celota defendía su creencia con gran fervor.\"", 3650, null, null },
                    { 11, "\"The zealot for human rights fought for equality.\"", "\"El defensor de los derechos humanos luchaba por la igualdad.\"", 5856, null, null },
                    { 12, "\"His zeal for his work allowed him to achieve great successes.\"", "\"El celo por su trabajo le permitió lograr grandes éxitos.\"", 3644, null, null },
                    { 13, "\"I like to zap (to) on social media to discover new trends.\"", "\"Me gusta zapear en las redes sociales para descubrir nuevas tendencias.\"", 19474, null, null },
                    { 14, "\"His zany style of clothing always attracted attention.\"", "\"El estilo estrafalario de su ropa siempre llamaba la atención.\"", 8054, null, null },
                    { 15, "\"Zagreb is the capital of Croatia.\"", "\"Zagreb es la capital de Croacia.\"", 19459, null, null },
                    { 16, "\"Yugoslavia was a country that existed in Southeast Europe.\"", "\"Yugoslavia fue un país que existió en el sureste de Europa.\"", 19450, null, null },
                    { 17, "\"The term Yugoslav refers to the peoples of the former Yugoslavia.\"", "\"El término yugoslavo se refiere a los pueblos de la antigua Yugoslavia.\"", 19451, null, null },
                    { 18, "\"His youthful attitude was refreshing and full of energy.\"", "\"Su actitud juvenil era refrescante y llena de energía.\"", 10645, null, null },
                    { 19, "\"Youth has many innovative ideas that will change the future.\"", "\"La juventud tiene muchas ideas innovadoras que cambiarán el futuro.\"", 10646, null, null },
                    { 20, "\"Where is your book?\"", "\"¿Dónde está tu libro?\"", 17422, null, null },
                    { 21, "\"Zurich is known for its high quality of life and economic stability.\"", "\"Zúrich es conocida por su alto nivel de calidad de vida y su estabilidad económica.\"", 19498, null, null },
                    { 22, "\"I used the zoom to get a clearer view of the details in the painting.\"", "\"Usé el zoom para poder ver los detalles del cuadro con más claridad.\"", 19489, null, null },
                    { 23, " estudié zoología porque siempre me han fascinado los animales.\"", "\"En la universidad", 19486, null, null },
                    { 24, "\"The zoologist gathered data during his research on gorillas.\"", "\"El zoólogo recogió datos durante su investigación sobre los gorilas.\"", 19488, null, null },
                    { 25, "\"The zoological park has a new exhibit of exotic birds.\"", "\"El zoológico tiene una nueva exposición de aves exóticas.\"", 19487, null, null },
                    { 26, "\"The kids have a lot of fun watching the animals at the zoo.\"", "\"Los niños se divierten mucho viendo a los animales en el zoo.\"", 19485, null, null },
                    { 27, " ideal para vivir.\"", "\"La zona residencial está muy tranquila", 19483, null, null },
                    { 28, "\"The parking zone is reserved for employees.\"", "\"La zona de estacionamiento es exclusiva para empleados.\"", 19484, null, null },
                    { 29, "\"The Chinese zodiac is based on a 12-year cycle.\"", "\"El zodíaco chino se basa en un ciclo de 12 años.\"", 19481, null, null },
                    { 30, "\"The zipper on my backpack broke when I zipped it up too quickly.\"", "\"La cremallera de mi mochila se rompió cuando la cerré demasiado rápido.\"", 5344, null, null },
                    { 31, "\"I heard a strange whistle coming from the hallway.\"", "\"Escuché un silbido extraño que provenía del pasillo.\"", 17001, null, null },
                    { 32, "\"Zion was an important symbol in religious scriptures.\"", "\"Sión fue un símbolo importante en las escrituras religiosas.\"", 17156, null, null },
                    { 33, "\"That movie has a zestful style that appeals to both children and adults.\"", "\"Esa película tiene un estilo animado que atrae tanto a niños como a adultos.\"", 1241, null, null },
                    { 34, "\"The number zero has a unique value in mathematics and science.\"", "\"El número cero tiene un valor único en matemáticas y ciencias.\"", 3743, null, null },
                    { 35, "\"They reached the zenith of their success when their album hit number one.\"", "\"Alcanzaron el cenit de su éxito cuando su álbum llegó al número uno.\"", 3670, null, null },
                    { 36, " vimos una cebra cruzando la carretera.\"", "\"En el safari", 3626, null, null },
                    { 37, " no le gusta compartir.\"", "\"Es muy celoso con sus pertenencias", 3649, null, null },
                    { 38, "\"She is such a zealous person that she spreads her energy to others.\"", "\"Es una persona tan entusiasta que contagia su energía a los demás.\"", 7557, null, null },
                    { 39, "\"Religious zealotry can be dangerous if taken to the extreme.\"", "\"El fanatismo religioso puede ser peligroso si se lleva al extremo.\"", 8282, null, null },
                    { 40, "\"The zealot was willing to give his life for his cause.\"", "\"El celota estaba dispuesto a dar su vida por su causa.\"", 3650, null, null },
                    { 41, "\"The zealot for civil rights fought for equality in society.\"", "\"El defensor de los derechos civiles luchó por la igualdad en la sociedad.\"", 5856, null, null },
                    { 42, "\"His zeal for excellence has made him a leader in his field.\"", "\"Su celo por la excelencia lo ha llevado a ser un líder en su campo.\"", 3644, null, null },
                    { 43, "\"I love zapping between channels until I find something interesting.\"", "\"Me encanta zapear entre canales hasta encontrar algo interesante.\"", 19474, null, null },
                    { 44, "\"His zany behavior made him famous at school.\"", "\"Su comportamiento estrafalario lo hizo famoso en la escuela.\"", 8054, null, null },
                    { 45, "\"Zagreb is a vibrant city with a lot of history and culture.\"", "\"Zagreb es una ciudad vibrante con mucha historia y cultura.\"", 19459, null, null },
                    { 46, "\"Yugoslavia was a country that left a significant mark on European history.\"", "\"Yugoslavia fue un país que dejó una huella importante en la historia de Europa.\"", 19450, null, null },
                    { 47, " con influencias balcánicas.\"", "\"La comida yugoslava es muy variada y deliciosa", 19451, null, null },
                    { 48, "\"His youthful personality always brought a refreshing energy to the group.\"", "\"Su personalidad juvenil siempre traía una energía renovadora al grupo.\"", 10645, null, null },
                    { 49, "\"Today's youth is more globally connected than ever before.\"", "\"La juventud de hoy está más conectada globalmente que nunca antes.\"", 10646, null, null },
                    { 50, " ¿puedes explicar más?\"", "\"Tu respuesta no me parece correcta", 17422, null, null }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Frases_Termsid",
                table: "Frases",
                column: "Termsid");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Frases");
        }
    }
}
