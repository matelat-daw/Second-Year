﻿using AUT02_05.Data;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.General;
using NuGet.Protocol.Core.Types;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Security.Cryptography.Xml;

namespace AUT02_05.Models
{
    public class Frases
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "El Campo es Requerido"), StringLength(100, MinimumLength = 5, ErrorMessage = "El Tamaño Mínimo de la Frase Debe Ser de 5 Caracteres.")]
        public string? SpanishFrase { get; set; }
        [Required(ErrorMessage = "El Campo es Requerido"), StringLength(100, MinimumLength = 5, ErrorMessage = "El Tamaño Mínimo de la Frase Debe Ser de 5 Caracteres.")]
        public string? EnglishFrase { get; set; }
        [ForeignKey("TermId")]
        public int TermId { get; set; }
        public Espeng? Terms { get; set; }
        public string? UserId { get; set; }
    }
}