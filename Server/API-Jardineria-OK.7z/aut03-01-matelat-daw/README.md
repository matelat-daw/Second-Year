# AUT03_01
Realizar las acciones descritas en el siguiente [documento](https://docs.google.com/document/d/1Wlj_SDyhfstgDur3DJazOVyMwq0qPu1I6o7aSdzWE30/edit?usp=sharing) para cumplir con todos los requisitos detallados en el mismo. En dicho documento se podrá ir elazando todos los recursos que se puedan necesitar para realizar correctamente la actividad.

Se ha de partir del proyecto que contiene este repositorio, tomándolo como base para desarrollar las funcionalidades solicitadas.

Se adjunta archivo .sql para generar la base de datos necesaria para realizar esta actividad.

Se han realizar commits y subidas de cambios por cada funcionalidad significativa del proyecto (configuraciones básicas, generacion de tablas desde la BD, creación de nuevos modelos, adición de gestión de usuarios, inclusión de usuarios y roles, funcionalidades solicitadas, etc)

Además, se tendrá que realizar un informe pdf como indica en el documento y subir todo el proyecto comprimido en .zip a Evagd.
