﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Api_4_Games_Users.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

public class GameContext : IdentityDbContext
    {
        public GameContext (DbContextOptions<GameContext> options)
            : base(options)
        {
        }

        public DbSet<Api_4_Games_Users.Models.Game> Game { get; set; } = default!;

        public DbSet<Api_4_Games_Users.Models.Genre> Genre { get; set; } = default!;
    }
