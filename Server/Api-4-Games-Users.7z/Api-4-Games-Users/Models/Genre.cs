﻿using System.ComponentModel.DataAnnotations;

namespace Api_4_Games_Users.Models
{
    public class Genre
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "El Campo es Requerido"), Display(Name = "Nombre"), StringLength(12, MinimumLength = 2, ErrorMessage = "El Nombre Debe Tener al Menos 2 Caracteres.")]
        public string? Name { get; set; }
        public List<Game>? Games { get; set; }
    }
}