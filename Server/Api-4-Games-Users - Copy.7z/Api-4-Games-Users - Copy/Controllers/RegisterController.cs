﻿using Api_4_Games_Users.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;

namespace Api_4_Games_Users.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegisterController(UserManager<IdentityUser> userManager) : ControllerBase
    {
        private readonly UserManager<IdentityUser>? _userManager = userManager;

        [HttpPost, ActionName("OnPostAsync"), Route("Register")]
        public async Task<IActionResult> OnPostAsync(Register model)
        {
            IActionResult result = null;

            if (model.Password == model.Password2)
            {
                if (ModelState.IsValid)
                {
                    IdentityUser user = new IdentityUser
                    {
                        UserName = model.Email,
                        NormalizedUserName = model.Email.ToUpper(),
                        Email = model.Email,
                        NormalizedEmail = model.Email.ToUpper()
                    };

                    user = CreateUser();

                    var createUser = await _userManager.CreateAsync(user, model.Password);

                    if (createUser.Succeeded)
                    {

                        await _userManager.AddToRoleAsync(user, "Basic");

                        result = Ok("El Usuario: " + user.Email + " Ha Sido Registrado Correctamente.");
                    }
                    foreach (var error in createUser.Errors)
                    {
                        ModelState.AddModelError(string.Empty, error.Description);
                    }
                }
                else
                {
                    result = (IActionResult)ModelState;
                }
            }
            else
            {
                result = (IActionResult)ModelState;
            }

            return result;
        }

        private IdentityUser CreateUser()
        {
            try
            {
                return Activator.CreateInstance<IdentityUser>();
            }
            catch
            {
                throw new InvalidOperationException($"No se Puede Crear una Instancia de '{nameof(IdentityUser)}'. " +
                    $"Asegurate de qué '{nameof(IdentityUser)}' No es una Clase Abstracta y Tiene un Constructor sin Parametros o Altenativamente, Sobreescribe la Página de Registro en /Areas/Identity/Pages/Account/Register.cshtml");
            }
        }
    }
}