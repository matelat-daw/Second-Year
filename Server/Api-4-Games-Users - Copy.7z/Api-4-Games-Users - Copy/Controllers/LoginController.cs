﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using Api_4_Games_Users.Models;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Api_4_Games_Users.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController(SignInManager<IdentityUser> signInManager, UserManager<IdentityUser> userManager, IConfiguration configuration) : ControllerBase
    {
        private readonly UserManager<IdentityUser> _userManager = userManager;
        private readonly IConfiguration _configuration = configuration;
        private readonly SignInManager<IdentityUser> _signInManager = signInManager;

        //public class LoginModel
        //{
        //    [Required]
        //    [EmailAddress, Display(Name = "E-Mail")]
        //    public string? Email { get; set; }

        //    [Required]
        //    [DataType(DataType.Password), Display(Name = "Contraseña")]
        //    public string? Password { get; set; }
        //}

        //[BindProperty]
        //public LoginModel? Login { get; set; }

        [HttpPost, Route("Login")]
        // public async Task<IActionResult> OnPostAsync([FromBody] Login model)
        public async Task<IActionResult> OnPostAsync(Login model)
        {
            IActionResult? response = null;

            if (ModelState.IsValid)
            {
                IdentityUser user = await _userManager.FindByEmailAsync(model.Email);
                if (user != null)
                {
                    var result = await _signInManager.CheckPasswordSignInAsync(user, model.Password, false);
                    if (result.Succeeded)
                    {
                        var claims = new List<Claim>
                        {
                            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString() ),
                            new Claim(JwtRegisteredClaimNames.Iat, DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString()),
                            new Claim(JwtRegisteredClaimNames.Sub, user.UserName)
                        };

                        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:Key"]));
                        var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                        var token = new JwtSecurityToken
                            (
                                _configuration["Jwt:Issuer"],
                                _configuration["Jwt:Audience"],
                                claims,
                                expires: DateTime.UtcNow.AddMinutes(10),
                                signingCredentials: credentials
                            );
                        response = Ok("Usuario: " + model.Email + " Loguedo Correctamente. Tu Token es: " + new JwtSecurityTokenHandler().WriteToken(token));
                    }
                }
                else
                {
                    response = BadRequest("Las Credenciales no Pertenecen a Ningún Usuario Registrado.");
                }
            }

            return response;
            //}

            //IActionResult response = null; // Solución de Arturo.
            //if (ModelState.IsValid)
            //{
            //    IdentityUser user = await _userManager.FindByEmailAsync(model.Email);
            //    if (user == null)
            //    {
            //        response = Unauthorized("Credenciales no válidas");
            //    }
            //    else
            //    {
            //        var checkPassword = await _userManager.CheckPasswordAsync(user, model.Password);
            //        if (checkPassword)
            //        {
            //            var claims = new List<Claim>
            //            {
            //                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString() ),
            //                new Claim(JwtRegisteredClaimNames.Iat, DateTimeOffset.UtcNow.ToUnixTimeSeconds().ToString()),
            //                new Claim(JwtRegisteredClaimNames.Sub, user.UserName)
            //            };

            //            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:Key"]));
            //            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            //            var token = new JwtSecurityToken
            //                (
            //                    _configuration["Jwt:Issuer"],
            //                    _configuration["Jwt:Audience"],
            //                    claims,
            //                    expires: DateTime.UtcNow.AddMinutes(10),
            //                    signingCredentials: credentials
            //                );
            //            response = Ok(new JwtSecurityTokenHandler().WriteToken(token));
            //        }
            //    }
            //}
            //return response;
        }
    }
}
