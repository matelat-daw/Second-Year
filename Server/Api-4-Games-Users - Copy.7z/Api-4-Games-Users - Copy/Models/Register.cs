﻿using System.ComponentModel.DataAnnotations;

namespace Api_4_Games_Users.Models
{
    public class Register
    {
        [Required]
        [EmailAddress, Display(Name = "E-Mail")]
        public string? Email { get; set; }

        [Required]
        [DataType(DataType.Password), Display(Name = "Contraseña")]
        public string? Password { get; set; }
        [Required]
        [DataType(DataType.Password), Display(Name = "Repite Contraseña")]
        public string? Password2 { get; set; }
    }
}