[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/j25INRVR)
# PO02_01
Realizar las acciones descritas en el siguiente [documento](https://docs.google.com/document/d/1FqjzzKMXq40axwMN0zngqXi4dQpXzpMqzsVivGzRQ6M/edit?usp=sharing) para cumplir con todos los requisitos detallados en el mismo.

Se ha de partir del proyecto que contiene este repositorio, tomándolo como base para desarrollar las funcionalidades solicitadas.

Se adjunta archivo .sql para generar la base de datos necesaria para realizar esta actividad

El comportamiento de la aplicación ha de ser el que se muestra en el siguiente [video](https://drive.google.com/file/d/1SDzAI6iPhR0Pafj9JnjKCmlkhWVIjte8/view?usp=sharing)

Se ha de realizar una subida final de todo el proyecto a la finalización de la prueba.

Además, se tendrá que realizar un informe pdf como indica en el documento y subir todo el proyecto comprimido en .zip a Evagd.
