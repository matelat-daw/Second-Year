﻿using System.ComponentModel.DataAnnotations;

namespace Music.Models
{
    public class Review
    {
        [Key]
        public int ReviewId { get; set; }
        [Required(ErrorMessage = "El Campo es Requerido. Escribe el Título entre 3 y 10 Caracteres.")]
        [Display(Name = "Título: "), StringLength(10, MinimumLength = 3, ErrorMessage = "El Título Debe Tener al Menos 3 Caracteres.")]
        public string? Title { get; set; }

        [Required(ErrorMessage = "El Campo es Requerido. Escribe la Descripción entre 5 y 30 Caracteres."), Display(Name = "Descripción: "), StringLength(30, MinimumLength = 5, ErrorMessage = "La Descripción Debe Tener al Menos 5 Caracteres.")]
        public string? Description { get; set; }

        [Required(ErrorMessage = "El Campo es Requerido. Escribe un Valor entre 1 y 5."), Display(Name = "Valoración: "), Range(1, 5, ErrorMessage = "El Rango Debe Estar Entre 1 y 5.")]
        public int Rating { get; set; }

        public int ArtistId { get; set; }

        public virtual Artist? Artist { get; set; }
    }
}