using System.ComponentModel.DataAnnotations;

namespace Ejercicio_2_API.Models
{
    public class Games
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "El Campo es Requerido."), Display(Name = "Título"), StringLength(50, MinimumLength = 5, ErrorMessage = "El Título Debe Tener al Menos 5 Caracteres.")]
        public string? Title { get; set; }
        [Required(ErrorMessage = "El Campo es Requerido."), Display(Name = "Título"), StringLength(50, MinimumLength = 5, ErrorMessage = "El Género Debe Tener al Menos 5 Caracteres.")]
        public string? Genre { get; set; }
    }
}