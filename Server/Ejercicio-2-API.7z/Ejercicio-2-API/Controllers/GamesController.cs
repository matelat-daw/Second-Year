using Ejercicio_2_API.Models;
using Microsoft.AspNetCore.Mvc;

namespace Ejercicio_2_API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class GamesController : ControllerBase
    {
        private static readonly Games game1 = new()
        {
            Id = 1,
            Title = "The Secret of Monkey Island",
            Genre = "Adventure"
        };
        private static readonly Games game2 = new()
        {
            Id = 2,
            Title = "Tomb Raider",
            Genre = "Action/Adventure"
        };
        private static readonly Games game3 = new()
        {
            Id = 3,
            Title = "Mimi & The Mites",
            Genre = "Wit/Strategy"
        };
        public static List<Games> games =
        [
            game1, game2, game3
        ];

        private readonly ILogger<GamesController> _logger;

        public GamesController(ILogger<GamesController> logger)
        {
            _logger = logger;
        }

        [HttpGet(Name = "Games")]
        public IEnumerable<Games> Get()
        {
            return [.. games];
        }

        [HttpGet("{id}")]
        public IActionResult Read(int id)
        {
            if (id <= games.Count && id > 0)
            {
                var game = games[id - 1];
                return Ok(game);
            }
            else
            {
                return BadRequest("No Che Esa ID no Está en la Base de Datos.");
            }
        }

        [HttpPost]
        public IActionResult Create(Games game)
        {
            games.Add(game);
            return Created(string.Empty, games);
        }

        [HttpPut("{id}")]
        public IActionResult Update(Games game)
        {
            var index = games.FindIndex(r => r.Id == game.Id);

            if (index != -1)
            {
                games[index] = game;
            }

            return Ok(game);
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            int index = games.FindIndex(i => i.Id == id);
            games.RemoveAt(index);
            return NoContent();
        }
    }
}
