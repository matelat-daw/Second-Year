﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

function toast(code, ttl, msg) {
    var alerta = document.getElementById("alerta"); // La ID del botón del dialogo.
    var title = document.getElementById("title"); // Asigno a la variable title el h4 con id title.
    var message = document.getElementById("message"); // Asigno a la variable message el h5 con id message;

    switch (code) {
        case 0:
            title.style.backgroundColor = "#FFFFFF"; // Pongo los atributos, color de fondo negro.
            title.style.color = "blue"; // Y color del texto amarillo.
            break;
        case 1:
            title.style.backgroundColor = "#000000"; // Pongo los atributos, color de fondo negro.
            title.style.color = "yellow"; // Y color del texto amarillo.
            break;
        default:
            title.style.backgroundColor = "#000000"; // Pongo los atributos, color de fondo negro.
            title.style.color = "red"; // Y color del texto rojo.
            break;
    }
    title.innerHTML = ttl; // Muestro el Título del dialogo.
    message.innerHTML = msg; // Muestro los mensajes en el diálogo.
    alerta.click(); // Lo hago aparecer pulsando el botón con ID alerta.
}

function checkIt() // Función que Verifica si Se Aceptó la Política de Privaciadad.
{
    let check = document.getElementById("check"); // ID de la ChackBox.

    if (check.checked) // Si la CheckBox está Chequeada.
    {
        return true; // Retorna true y Envía el Formulario.
    }
    toast(2, "Lo Siento:", "No Puedes Registrarte si no Aceptas Nuestra Política de Privacidad. Gracias."); // Muestro el Mensaje que no Puedes Registrarte sin Aceptar la Política de Privacidad.
    return false; // Retorna false, el Formulario no se Envía
}