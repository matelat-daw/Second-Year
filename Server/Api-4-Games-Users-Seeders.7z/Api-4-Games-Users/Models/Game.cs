﻿using System.ComponentModel.DataAnnotations;

namespace Api_4_Games_Users.Models
{
    public class Game
    {
        [Key]
        public int Id { get; set; }
        [Required (ErrorMessage = "El Campo es Requerido."), Display(Name = "Nombre"), StringLength(15, MinimumLength = 5, ErrorMessage = "El Nombre Debe Tener al Menos 5 Caracters.")]
        public string? Name { get; set; }
        [Required (ErrorMessage = "El Campo es Requerido."), Display(Name = "Precio"), Range(1, 100, ErrorMessage = "El Precio Debe ser Mayor que 0 y Menor o Igual a 100 Euros.")]
        public int Price { get; set; }
        public int GenreId { get; set; }
    }
}