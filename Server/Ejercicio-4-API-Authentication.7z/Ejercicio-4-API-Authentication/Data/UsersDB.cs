﻿#nullable disable
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Ejercicio_4_API_Authentication.Data;
    public partial class UsersDB: IdentityDbContext
    {
        public UsersDB(DbContextOptions<UsersDB> options) : base(options){ }
    }