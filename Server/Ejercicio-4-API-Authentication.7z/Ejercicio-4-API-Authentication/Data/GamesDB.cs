﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Ejercicio_4_API_Authentication.Models;

    public class GamesDB : DbContext
    {
        public GamesDB (DbContextOptions<GamesDB> options)
            : base(options)
        {
        }

        public DbSet<Ejercicio_4_API_Authentication.Models.Games> Games { get; set; } = default!;

public DbSet<Ejercicio_4_API_Authentication.Models.Genres> Genres { get; set; } = default!;
    }
