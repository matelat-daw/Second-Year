﻿using System.ComponentModel.DataAnnotations;

namespace Ejercicio_4_API_Authentication.Models
{
    public class Genres
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Campo Requerido."), Display(Name = "Nombre"), StringLength(12, MinimumLength = 2, ErrorMessage = "El Nombre Debe Tener Como Mínimo 2 Caracteres y un Máximo de 12.")]
        public string? Name { get; set; }
        public List<Games>? Games { get; set; }
    }
}