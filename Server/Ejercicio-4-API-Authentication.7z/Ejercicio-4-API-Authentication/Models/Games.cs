﻿using System.ComponentModel.DataAnnotations;

namespace Ejercicio_4_API_Authentication.Models
{
    public class Games
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage = "Campo Requerido."), Display(Name = "Nombre"), StringLength(15, MinimumLength = 5, ErrorMessage = "El Nombre Debe Tener Como Mínimo 5 Caracteres y un Máximo de 15.")]
        public string? Name { get; set; }
        public int GenresId { get; set; }
        public Genres? Genres { get; set; }
    }
}