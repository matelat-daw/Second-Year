var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

app.MapGet("/", () => "César: Proyecto ASP.NET Core Vacío");

app.Run();
