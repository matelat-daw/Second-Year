﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AUT02_05.Migrations.Diccionario
{
    /// <inheritdoc />
    public partial class Frases : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "FrasesModel",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SpanishFrase = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    EnglishFrase = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TermsId = table.Column<int>(type: "int", nullable: false),
                    UserId = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FrasesModel", x => x.Id);
                    table.ForeignKey(
                        name: "FK_FrasesModel_Espeng_TermsId",
                        column: x => x.TermsId,
                        principalTable: "Espeng",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_FrasesModel_TermsId",
                table: "FrasesModel",
                column: "TermsId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "FrasesModel");
        }
    }
}
