﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.General;
using System.Data;
using System.Security.Claims;
using IdentityDbContext = Microsoft.AspNetCore.Identity.EntityFrameworkCore.IdentityDbContext;

namespace AUT02_05.Data
{
    //public class ApplicationUser : IdentityUser
    //{
    //    public async Task<ClaimsIdentity> GenerateUserIdentityAsync(Microsoft.AspNetCore.Identity.UserManager<ApplicationUser> manager)
    //    {
    //        // Note the authenticationType must match the one defined in CookieAuthenticationOptions.AuthenticationType
    //        var userIdentity = await manager.CreateIdentityAsync(this, DefaultAuthenticationTypes.ApplicationCookie);
    //        // Add custom user claims here
    //        return userIdentity;
    //    }
    //}

    public class CesarContext : IdentityDbContext
    {
        public CesarContext(DbContextOptions<CesarContext> options)
        : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            IdentityRole adminRole = new()
            {
                Name = "Administrator"
            };
            adminRole.NormalizedName = adminRole.Name.ToUpper();

            IdentityRole userRole = new()
            {
                Name = "Basic"
            };
            userRole.NormalizedName = userRole.Name.ToUpper();

            IdentityRole premiumRole = new()
            {
                Name = "Premium"
            };
            premiumRole.NormalizedName = premiumRole.Name.ToUpper();

            List<IdentityRole> roles =
            // Lista de Roles de Usuarios.
            [
                adminRole, userRole, premiumRole
            ];

            IdentityUser admin = new IdentityUser
            {
                UserName = "admin@northwind.com",
                Email = "admin@northwind.com"
            };
            admin.NormalizedUserName = admin.UserName.ToUpper();
            admin.NormalizedEmail = admin.Email.ToUpper();

            IdentityUser user = new()
            {
                UserName = "cesarmatelat@northwind.com",
                Email = "cesarmatelat@northwind.com"
            };
            user.NormalizedUserName = user.UserName.ToUpper();
            user.NormalizedEmail = user.Email.ToUpper();

            IdentityUser premium = new()
            {
                UserName = "premium@northwind.com",
                Email = "premium@northwind.com"
            };
            premium.NormalizedUserName = premium.UserName.ToUpper();
            premium.NormalizedEmail = premium.Email.ToUpper();

            List<IdentityUser> users =
            [
                admin, user, premium
            ];

            var passwordHasher = new PasswordHasher<IdentityUser>(); // Crea las Contraseñas de los tres Usuarios de la Lista de Usuarios.
            users[0].PasswordHash = passwordHasher.HashPassword(users[0], "Password-1");
            users[1].PasswordHash = passwordHasher.HashPassword(users[1], "Password-2");
            users[2].PasswordHash = passwordHasher.HashPassword(users[2], "Password-3");

            IdentityUserRole<string> userRoleAdmin = new()
            {
                UserId = users[0].Id,
                RoleId = roles[0].Id
            };

            IdentityUserRole<string> userRoleUser = new()
            {
                UserId = users[1].Id,
                RoleId = roles[1].Id
            };

            IdentityUserRole<string> userRolePremium = new()
            {
                UserId = users[2].Id,
                RoleId = roles[2].Id
            };

            List<IdentityUserRole<string>> userRoles =
            // Lista de los Roles de los Usuarios Registrados.
            [
                userRoleAdmin, userRoleUser, userRolePremium
            ];

            modelBuilder.Entity<IdentityRole>().HasData(roles); // Roles a Almacenar en la Base de Datos Northwind en la Tabla AspNetRoles.

            modelBuilder.Entity<IdentityUser>().HasData(users); // Roles a Almacenar en la Base de Datos Northwind en la Tabla AspNetUsers.

            modelBuilder.Entity<IdentityUserRole<string>>().HasData(userRoles); // Roles a Almacenar en la Base de Datos Northwind en la Tabla AspNetUserRoles.

            base.OnModelCreating(modelBuilder);
        }
    }
}