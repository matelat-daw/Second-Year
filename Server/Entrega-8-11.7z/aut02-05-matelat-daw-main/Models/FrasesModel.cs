﻿using AUT02_05.Data;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc.Templates.General;
using NuGet.Protocol.Core.Types;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Security.Cryptography.Xml;

namespace AUT02_05.Models
{
    public class FrasesModel
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string? SpanishFrase { get; set; }
        [Required]
        public string? EnglishFrase { get; set; }
        public int TermsId { get; set; }
        public string? UserId { get; set; }
        [ForeignKey ("TermsId")]
        public Espeng? Terms { get; set; }
        [ForeignKey("UserId")]
        public CesarContext? Users { get; set; }
    }
}