﻿using Microsoft.AspNetCore.Mvc;

namespace Music.Controllers
{
    public class Logins : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
