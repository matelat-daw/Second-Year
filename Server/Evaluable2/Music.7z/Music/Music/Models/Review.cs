﻿using System.ComponentModel.DataAnnotations;

namespace Music.Models
{
    public class Review
    {
        [Key]
        public int ReviewId { get; set; }
        [Required, Display(Name = "Título: "), StringLength(10, MinimumLength = 3)]
        public string? Title { get; set; }

        [Required, Display(Name = "Descripción: "), StringLength(30, MinimumLength = 5)]
        public string? Description { get; set; }

        [Required, Display(Name = "Valoración: ")]
        public int Rating { get; set; }

        public int ArtistId { get; set; }

        public virtual Artist? Artist { get; set; }
    }
}