﻿using System.ComponentModel.DataAnnotations;

namespace Music.Models
{
    public class Review
    {
        [Key]
        public int Id { get; set; }
        [Required, Display(Name = "Título: "), StringLength(10, MinimumLength = 3)]
        public string? Title { get; set; }

        [Required, Display(Name = "Descripción: "), StringLength(30, MinimumLength = 5)]
        public string? Description { get; set; }

        [Required, Display(Name = "Valoración: "), RegularExpression(@"^\d+.\d{0,2}$"), Range(0.00, 5.00)]
        public decimal? valuation { get; set; }
    }
}