﻿using Microsoft.AspNetCore.Mvc;

namespace Music.Controllers
{
    public class LoginsController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
