﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace AUT02_05.Data
{
    public class CesarContext: IdentityDbContext
    {
        public CesarContext(DbContextOptions<CesarContext> options)
        : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            IdentityRole adminRole = new()
            {
                Name = "admin"
            };
            adminRole.NormalizedName = adminRole.Name.ToUpper();

            IdentityRole userRole = new()
            {
                Name = "basic"
            };
            userRole.NormalizedName = userRole.Name.ToUpper();

            IdentityRole premiumRole = new()
            {
                Name = "premium"
            };
            premiumRole.NormalizedName = premiumRole.Name.ToUpper();

            List<IdentityRole> roles =
            // Lista de Roles de Usuarios.
            [
                adminRole, userRole, premiumRole
            ];

            IdentityUser admin = new IdentityUser
            {
                UserName = "admin@diccionario.com",
                Email = "admin@diccionario.com"
            };
            admin.NormalizedUserName = admin.UserName.ToUpper();
            admin.NormalizedEmail = admin.Email.ToUpper();

            IdentityUser user = new()
            {
                UserName = "basic@diccionario.com",
                Email = "basic@diccionario.com"
            };
            user.NormalizedUserName = user.UserName.ToUpper();
            user.NormalizedEmail = user.Email.ToUpper();

            IdentityUser premium = new()
            {
                UserName = "premium@diccionario.com",
                Email = "premium@diccionario.com"
            };
            premium.NormalizedUserName = premium.UserName.ToUpper();
            premium.NormalizedEmail = premium.Email.ToUpper();

            List<IdentityUser> users =
            [
                admin, user, premium
            ];

            var passwordHasher = new PasswordHasher<IdentityUser>(); // Crea las Contraseñas de los tres Usuarios de la Lista de Usuarios.
            users[0].PasswordHash = passwordHasher.HashPassword(users[0], "Admin123!");
            users[1].PasswordHash = passwordHasher.HashPassword(users[1], "Basic123!");
            users[2].PasswordHash = passwordHasher.HashPassword(users[2], "Premium123!");

            IdentityUserRole<string> userRoleAdmin = new()
            {
                UserId = users[0].Id,
                RoleId = roles[0].Id
            };

            IdentityUserRole<string> userRoleUser = new()
            {
                UserId = users[1].Id,
                RoleId = roles[1].Id
            };

            IdentityUserRole<string> userRolePremium = new()
            {
                UserId = users[2].Id,
                RoleId = roles[2].Id
            };

            List<IdentityUserRole<string>> userRoles =
            // Lista de los Roles de los Usuarios Registrados.
            [
                userRoleAdmin, userRoleUser, userRolePremium
            ];

            modelBuilder.Entity<IdentityRole>().HasData(roles); // Roles a Almacenar en la Base de Datos Northwind en la Tabla AspNetRoles.

            modelBuilder.Entity<IdentityUser>().HasData(users); // Roles a Almacenar en la Base de Datos Northwind en la Tabla AspNetUsers.

            modelBuilder.Entity<IdentityUserRole<string>>().HasData(userRoles); // Roles a Almacenar en la Base de Datos Northwind en la Tabla AspNetUserRoles.

            base.OnModelCreating(modelBuilder);
        }
    }
}