﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using AUT02_05.Data;
using AUT02_05.Models;
using AUT02_05.Controllers;

namespace AUT02_05.Controllers
{
    public class EspengsController : Controller
    {
        private readonly DiccionarioContext _context;

        public EspengsController(DiccionarioContext context)
        {
            _context = context;
        }

        // GET: Espengs
        public async Task<IActionResult> Index()
        {
            return View(await _context.Espeng.ToListAsync());
        }

        //public async Task<IActionResult> Index(string sortOrder, string currentFilter, string searchString, int? pageNumber)
        //{
        //    ViewData["NameSortParm"] = String.IsNullOrEmpty(sortOrder) ? "name" : "";
        //    ViewData["CurrentFilter"] = searchString;
        //    var terms = from s in _context.Espeng.Include(a => a.ing) // Esto va así, hay que agregar los Usuarios que escriben los comentarios.
        //                select s;

        //    if (searchString != null)
        //    {
        //        pageNumber = 1;
        //    }
        //    else
        //    {
        //        searchString = currentFilter;
        //    }

        //    if (!String.IsNullOrEmpty(searchString))
        //    {
        //        terms = terms.Where(s => s.ing.Contains(searchString));
        //    }

        //    switch (sortOrder)
        //    {
        //        case "name":
        //            terms = terms.OrderBy(a => a.ing);
        //            break;
        //        default:
        //            terms = terms.OrderByDescending(a => a.ing);
        //            break;
        //    }

        //    int pageSize = 30;
        //    return View(await PaginatedList<Espeng>.CreateAsync(terms.AsNoTracking(), pageNumber ?? 1, pageSize));
        //}

        // GET: Espengs/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var espeng = await _context.Espeng
                .FirstOrDefaultAsync(m => m.id == id);
            if (espeng == null)
            {
                return NotFound();
            }

            return View(espeng);
        }

        // GET: Espengs/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Espengs/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("id,esp,ing")] Espeng espeng)
        {
            if (ModelState.IsValid)
            {
                _context.Add(espeng);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(espeng);
        }

        // GET: Espengs/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var espeng = await _context.Espeng.FindAsync(id);
            if (espeng == null)
            {
                return NotFound();
            }
            return View(espeng);
        }

        // POST: Espengs/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("id,esp,ing")] Espeng espeng)
        {
            if (id != espeng.id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(espeng);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!EspengExists(espeng.id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(espeng);
        }

        // GET: Espengs/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var espeng = await _context.Espeng
                .FirstOrDefaultAsync(m => m.id == id);
            if (espeng == null)
            {
                return NotFound();
            }

            return View(espeng);
        }

        // POST: Espengs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var espeng = await _context.Espeng.FindAsync(id);
            if (espeng != null)
            {
                _context.Espeng.Remove(espeng);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool EspengExists(int id)
        {
            return _context.Espeng.Any(e => e.id == id);
        }
    }
}
