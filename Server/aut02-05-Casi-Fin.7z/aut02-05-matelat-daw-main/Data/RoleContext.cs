﻿using Microsoft.AspNetCore.Identity;

namespace AUT02_05.Data
{
    public class RoleContext : IdentityRole
    {
        public RoleContext()
        {

        }
    }
}