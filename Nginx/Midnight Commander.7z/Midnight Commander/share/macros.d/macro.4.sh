#silent
t       Indent `C' formatter
        indent -gnu -fc1 -i4 -bli0 -nut -bap -l100 %b 1>/dev/null 2> %e
